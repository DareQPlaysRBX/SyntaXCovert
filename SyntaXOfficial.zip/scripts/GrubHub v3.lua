loadstring(game:HttpGet("https://raw.githubusercontent.com/Boxking776/GrubHubNonPremium/main/GrubGubMain.lua"))()
-- Klucz:jbd8y36JIJFDK542kd