getgenv().Auto = false --[ True or False]
getgenv().BoxType = "Knife" --[ Knife, Pistol, Animal]
getgenv().Option = "One" --[ One, Two, Three, Four]
getgenv().Speed = 0.6 --[ How Fast it Goes]


loadstring(game:HttpGet(('https://raw.githubusercontent.com/DohmBoyOG/Script-Dump/main/MurderMysteryX_AutoBox_DohmScripts_Public.lua'),true))()