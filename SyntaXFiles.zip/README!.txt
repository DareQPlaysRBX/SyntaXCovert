Hello!
Whoever you are, I just want to tell you that SyntaXCovert does not have its own DLL!
Our project uses a Custom DLL borrowed from another exploits (it is currently Comet.dll)

More informations about "Comet" here:
https://cometrbx.xyz/credits.html
                                     Thank you for your understanding,
                                             DareQPlaysRBX#1001